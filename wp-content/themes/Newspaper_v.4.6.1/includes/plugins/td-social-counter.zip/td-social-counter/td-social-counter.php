<?php
/*
	Plugin Name: tagDiv Social Counter
	Plugin URI: http://tagdiv.com
	Description: Social counter for wordpress. Widget and visual composer block.
	Author: tagDiv
	Version: 2.7
	Author URI: http://tagdiv.com
*/


// load the api
require_once 'td_social_api.php';


//$td_social_api = new td_social_api();
//print_r($td_social_api->get_google_plus('106192958286631454676'));
//print_r($td_social_api->get_twitter('tagDiv'));
//print_r($td_social_api->get_vimeo('brad'));
//print_r($td_social_api->td_cache);


//$td_social_api->set_cache('test1', 'user_id', 'data');
//echo $td_social_api->get_cache('test1', 'user_id');
//$td_social_api->set_cache('ra2', 'raid', 'data');




//print_r($td_social_api->get_facebook('tagdiv'));
//print_r($td_social_api->get_youtube('rathegod'));
//$td_social_api->save_transient();



function td_social_counter_init() {

    /**
     * read the theme constants
     */
    $td_theme_name = '';
    if (defined('TD_THEME_NAME')) {
        $td_theme_name = TD_THEME_NAME;
    }


    /**
     * if we run Newspaper, we need to load this another way.
     */
    if ($td_theme_name == 'Newsmag') {
        // on 010 load the new version
        include 'shortcode/td_social_counter_010.php';
    }


    elseif ($td_theme_name == 'Newspaper') {
        // on newspaper load the legacy version
        include 'shortcode/td_social_counter_009.php';
    }


}


add_action('td_wp_booster_loaded', 'td_social_counter_init');